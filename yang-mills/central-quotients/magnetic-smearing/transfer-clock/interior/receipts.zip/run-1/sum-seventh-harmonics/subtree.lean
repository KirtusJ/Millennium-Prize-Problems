
theorem harmonicSeven :
    (8:ℤ)^7-8*6^7+28*4^7-56*2^7 = 309248 := by decide

theorem shiftedMeanSquare :
    (4:ℚ)*(1/12)/(151/630)=210/151 := by norm_num

#print axioms twoLegs
#print axioms centeredWindowWidth
#print axioms geometricRatio
#print axioms windowExample
#print axioms finiteWindowTrace
#print axioms shiftedFour
#print axioms shiftedSquare
#print axioms shiftedNorm
#print axioms independentProduct
#print axioms harmonicSeven
#print axioms shiftedMeanSquare
end InteriorClock
