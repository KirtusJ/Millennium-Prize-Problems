
theorem mixedMass {a b m : ℝ} (h : m ≤ a+b) : m/2 ≤ a ∨ m/2 ≤ b := by
  by_contra! hn
  linarith

theorem spinWeight {z : ℝ} (h : z^2 ≤ 1/4) : 9/16 ≤ (1-z^2)^2 := by
  nlinarith [sq_nonneg (1/4-z^2)]

theorem fejerFour (x : ℝ) :
    (x*(2*x-1)^2)^2 = x^2-8*x^3+24*x^4-32*x^5+16*x^6 := by ring

theorem fourClockNorm : (1+8+24+32+16 : ℕ) = 81 := by decide

theorem harmonicFive :
    (56:ℤ)*2^5-28*4^5+8*6^5-8^5 = 2560 := by decide

theorem movingMean : (2/3:ℚ)*(1/12)/(20/240)*4 = 8/3 := by norm_num

#print axioms excess
#print axioms fiberWidth
#print axioms sparseFiber
#print axioms conditionalConstant
#print axioms mixedMass
#print axioms spinWeight
#print axioms fejerFour
#print axioms fourClockNorm
#print axioms harmonicFive
#print axioms movingMean
end MovingThreshold
