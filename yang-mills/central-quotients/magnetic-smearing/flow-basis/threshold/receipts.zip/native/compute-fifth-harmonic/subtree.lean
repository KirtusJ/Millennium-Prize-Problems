
theorem harmonicFive :
    (56:ℤ)*2^5-28*4^5+8*6^5-8^5 = 2560 := by decide

theorem movingMean : (2/3:ℚ)*(1/12)/(20/240)*4 = 8/3 := by norm_num

#print axioms excess
#print axioms fiberWidth
#print axioms sparseFiber
#print axioms conditionalConstant
#print axioms mixedMass
#print axioms spinWeight
#print axioms fejerFour
#print axioms fourClockNorm
#print axioms harmonicFive
#print axioms movingMean
end MovingThreshold
