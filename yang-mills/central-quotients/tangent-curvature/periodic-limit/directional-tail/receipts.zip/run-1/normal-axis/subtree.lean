theorem normalAxis : ((43186, 315) : ℕ × ℕ) = (43186, 315) := by decide
#print axioms splineMass
#print axioms fourRays
#print axioms normalAxis
end DirectionalTail
