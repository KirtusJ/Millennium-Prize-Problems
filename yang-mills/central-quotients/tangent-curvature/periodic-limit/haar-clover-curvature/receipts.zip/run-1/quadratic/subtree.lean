theorem quadratic : (48:ℚ)*((1/4-1/8)/(4*256)-(3/4096)/4) = -3/1024 := by norm_num
#print axioms centerCount
#print axioms siteCount
#print axioms contact
#print axioms quadratic
end HaarClover
