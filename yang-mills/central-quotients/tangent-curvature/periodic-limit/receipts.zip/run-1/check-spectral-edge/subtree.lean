theorem slowMoment {q z b : ℝ} (hz : 0 ≤ z) (hzq : z < q) (hb : 0 < b) :
    ∃ n : ℕ, z^n < b*q^n := by
  have hq : 0 < q := lt_of_le_of_lt hz hzq
  have hlim := tendsto_pow_atTop_nhds_zero_of_lt_one (div_nonneg hz hq.le)
      ((div_lt_one hq).2 hzq)
  obtain ⟨n,hn⟩ := ((tendsto_order.1 hlim).2 b hb).exists
  refine ⟨n, ?_⟩
  rw [div_pow] at hn
  exact (div_lt_iff₀ (pow_pos hq n)).1 hn

theorem spectralEdge (r : ℕ → ℝ) (a : ℕ → ℕ → ℝ) (c : ℕ → ℝ)
    (hr : ∀ j, 0 ≤ r j ∧ r j ≤ 1)
    (ha : ∀ j n, a j n ≤ (r j)^n)
    (hl : ∀ n, Tendsto (fun j => a j n) atTop (𝓝 (c n)))
    (hs : ∀ q : ℝ, 0 < q → q < 1 → ∃ b > 0, ∀ n : ℕ, b*q^n ≤ c n) :
    Tendsto r atTop (𝓝 1) := by
  apply tendsto_order.2
  constructor
  · intro z hz
    by_cases hneg : z < 0
    · exact Filter.Eventually.of_forall fun j => hneg.trans_le (hr j).1
    have hq : z < (z+1)/2 := by linarith
    obtain ⟨b,hb,h⟩ := hs ((z+1)/2) (by linarith) (by linarith)
    obtain ⟨n,hn⟩ := slowMoment (le_of_not_gt hneg) hq hb
    have hev := ((tendsto_order.1 (hl n)).1 _ (hn.trans_le (h n)))
    filter_upwards [hev] with j hj
    by_contra! hle
    exact (not_lt_of_ge (pow_le_pow_left₀ (hr j).1 hle n)) (hj.trans_le (ha j n))
  · intro z hz
    exact Filter.Eventually.of_forall fun j => (hr j).2.trans_lt hz

theorem slowExample : 32 * (2 : ℕ)^9 < 3^9 := by decide

#print axioms seamExponent
#print axioms forestFour
#print axioms faceMultiplicity
#print axioms dipoleCancels
#print axioms energyIdentity
#print axioms pressureMean
#print axioms faceCensus
#print axioms slowMoment
#print axioms spectralEdge
#print axioms slowExample
end PeriodicCriticality
