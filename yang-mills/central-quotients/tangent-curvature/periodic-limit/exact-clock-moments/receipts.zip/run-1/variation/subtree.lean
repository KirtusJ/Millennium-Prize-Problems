theorem variation : (3+10+15 : ℕ) = 28 := by decide
#print axioms equalCount
#print axioms unmatchedThird
#print axioms quadratic
#print axioms variation
end ExactClock
