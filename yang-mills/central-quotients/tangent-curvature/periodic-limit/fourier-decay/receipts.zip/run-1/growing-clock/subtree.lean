theorem separatedWindows : (50 : ℕ) = 50 := by decide
#print axioms radialConstant
#print axioms relativeMoment
#print axioms separatedWindows
end FourierDecay
