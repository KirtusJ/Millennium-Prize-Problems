theorem foldedPairs : ((24, 0) : ℕ × ℕ) = (24,0) := by decide

theorem budget (signal approximation moment : ℝ)
    (hs : 0 < signal) (ha : approximation ≤ signal/4)
    (hm : moment ≤ signal/4) :
    0 < signal - approximation - moment := by linarith

theorem twoLegChecks : ((14, 7332) : ℕ × ℕ) = (14,7332) := by decide

theorem transverseRadius (e p : ℝ) (hp : 0 ≤ p) (he : p < e) :
    (p/2)^2 + (Real.sqrt (e^2-p^2)/2)^2 = (e/2)^2 := by
  have h : 0 ≤ (e-p)*(e+p) := mul_nonneg (by linarith) (by linarith)
  have hs := Real.sq_sqrt (show 0 ≤ e^2-p^2 by nlinarith)
  nlinarith

#print axioms signedPathCounts
#print axioms wickExcess
#print axioms foldedPairs
#print axioms budget
#print axioms twoLegChecks
#print axioms transverseRadius
end JointMomentum
