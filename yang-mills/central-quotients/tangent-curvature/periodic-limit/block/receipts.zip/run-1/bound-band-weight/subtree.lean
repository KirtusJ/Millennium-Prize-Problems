theorem bandWeight {X : Type*} [MeasurableSpace X] (μ : Measure X)
    (J : Set X) (f : X → ℝ) (hf : Integrable f μ)
    (hi : Integrable (J.indicator (fun _ : X => (1:ℝ))) μ)
    (hin : ∀ x ∈ J, f x ≤ 1) (hout : ∀ x ∉ J, f x ≤ 0) :
    (∫ x, f x ∂μ) ≤ ∫ x, J.indicator (fun _ : X => (1:ℝ)) x ∂μ := by
  apply integral_mono hf hi
  intro x
  by_cases h : x ∈ J
  · simpa [Set.indicator_of_mem h] using hin x h
  · simpa [Set.indicator, h] using hout x h

theorem timeWitness {n m v c B : ℝ} (hn : 0 < n) (hc : 0 < c) (hv : v ≤ 1)
    (hl : c ≤ B) (ht : B ≤ Real.exp (-m*n)*v) : m ≤ -Real.log c/n := by
  have h : c ≤ Real.exp (-m*n) := calc
    c ≤ B := hl
    _ ≤ Real.exp (-m*n)*v := ht
    _ ≤ Real.exp (-m*n)*1 := mul_le_mul_of_nonneg_left hv (Real.exp_pos _).le
    _ = _ := mul_one _
  have hlog := Real.log_le_log hc h
  rw [Real.log_exp] at hlog
  exact (le_div_iff₀ hn).2 (by linarith)

theorem bandExample : (1*(-1)*3+14*1*1+1*3*(-1) : ℤ) = 8 := by decide

#print axioms thirdDifference
#print axioms boxMoment
#print axioms pathBound
#print axioms summedError
#print axioms spatialVisits
#print axioms bandWeight
#print axioms timeWitness
#print axioms bandExample
end WilsonBlock
