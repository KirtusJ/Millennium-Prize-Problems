/home/user/z4-workers/z1-mix6/build/g4_replicas fixed 3.276133577 1716289 0 288 144 6 12 -1
