from fractions import Fraction as F
from itertools import product
import json
# Reversible chain with uniform law and two distinct nontrivial positive eigenvalues.
P = [[F(3,4),F(1,4),F(0)],[F(1,4),F(1,2),F(1,4)],[F(0),F(1,4),F(3,4)]]
# verify via the eigenvectors (1,0,-1) and (1,-2,1).
vectors = [(F(3,4),[1,0,-1]),(F(1,4),[1,-2,1])]
for b,v in vectors:
    assert [sum(p*x for p,x in zip(row,v)) for row in P]==[b*x for x in v]
f = [a+b for a,b in zip(vectors[0][1],vectors[1][1])]
Q = P
out=[]
for k in range(1,4):
    g=[sum(b**k*v[i]/(1+b**(2*k)) for b,v in vectors) for i in range(3)]
    mse=sum(Q[i][j]*Q[j][l]*(f[j]-g[i]-g[l])**2/3 for i,j,l in product(range(3),repeat=3))
    expected=sum(sum(x*x for x in v)*F(1,3)*(1-b**(2*k))/(1+b**(2*k)) for b,v in vectors)
    assert mse==expected
    out.append(str(mse))
    Q=[[sum(Q[i][h]*P[h][l] for h in range(3)) for l in range(3)] for i in range(3)]
D,l,w=F(3,200),F(1,512),F(3,400)
r=(D-w-l)/(1-w-l)
assert r==F(71,12679) and (1-r)/(1+r)==F(6304,6375)
assert (D-r)/(1-r)-l==w
assert D-F(71,12800)-l==w
print(json.dumps({"two_sided_errors":out,"upper_transfer_squared":"6304/6375"}))
